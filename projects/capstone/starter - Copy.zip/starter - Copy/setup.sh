export DATABASE_PATH_1 = 'postgresql://akpvbtmdrgitgv:679d1bb6ad4540c6177efab3d8004a8edc4580217a58904acf8ef00efb184a6a@ec2-3-218-158-102.compute-1.amazonaws.com:5432/d9gb3vss8tob89'

export Auth0_Domain_Name='dev-fwwfme-j.us.auth0.com' 
export JWT_Code_Signing_Secret='-zsz8velXfhMeK6mexmgLTbD a8cXr79bO7CeN-I9M6L0WtpyjXKFTuZukY9VoKD-'
export Auth0_Client_ID='eVbMiEiwFCmH8wsbsxb403xJYbrhJMwG'